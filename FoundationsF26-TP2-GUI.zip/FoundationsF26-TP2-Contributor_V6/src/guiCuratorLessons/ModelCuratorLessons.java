package guiCuratorLessons;

import database.Database;
import entityClasses.LessonsLearnedList;

/*******
 * <p> Title: ModelCuratorLessons Class. </p>
 * <p> Description: Supplies the Curator GUI with lessons and lock operations. </p>
 * @version 1.00 2026-10-16 Initial TP2 implementation
 */
public class ModelCuratorLessons {

    /**
     * Constructs a ModelCuratorLessons object.
     */
    public ModelCuratorLessons() {
    }

    private static Database theDatabase = applicationMain.FoundationsMain.database;
    /**
     * <p> Method: getLessons(String username) </p>
     * <p> Description: Retrieves lessons for a Curator to review. </p>
     * @param username the logged-in Curator
     * @return lessons available for Curator review
     */
    protected static LessonsLearnedList getLessons(String username) {
        return theDatabase.getAllLessonsForCurator(username);
    }
    /**
     * <p> Method: setLocked() </p>
     * <p> Description: Changes the lock state of a lesson. </p>
     * @param id the lesson identifier
     * @param locked requested state
     * @param username curator
     * @return true when the lock state was changed
     */
    protected static boolean setLocked(int id, boolean locked, String username) {
        return theDatabase.setLessonLockedByCurator(id, locked, username);
    }
    /**
     * <p> Method: setFieldLocked() </p>
     * <p> Description: Changes the lock state of an individual lesson field. </p>
     * @param lessonId the lesson identifier
     * @param field the field to lock or unlock
     * @param locked true to lock the field; false to unlock it
     * @param username the logged-in Curator
     * @return true if the lock was updated; otherwise false
     */
    protected static boolean setFieldLocked(int lessonId, String field, boolean locked, String username) {
        return theDatabase.setLessonFieldLockedByCurator(
                lessonId, field, locked, username);
    }

}
