package guiCuratorLessons;

import entityClasses.LessonsLearned;
import javafx.scene.control.Alert;

/*******
 * <p> Title: ControllerCuratorLessons Class. </p>
 * <p> Description: Handles the Curator's lock and unlock actions. </p>
 * @version 1.00 2026-10-16 Initial TP2 implementation
 */
public class ControllerCuratorLessons {

    /**
     * Constructs a ControllerCuratorLessons object.
     */
    public ControllerCuratorLessons() {
    }

    /** <p> Method: performLock(boolean locked) </p>
     * <p> Description: Changes the selected lesson's lock state and refreshes the list. </p>
     * @param locked true to lock the lesson; false to unlock it
     */
    protected static void performLock(boolean locked) {
        LessonsLearned lesson = ViewCuratorLessons.list_Lessons.getSelectionModel().getSelectedItem();
        if (lesson == null) {
            showMessage("Select a lesson first.");
            return;
        }
        if (!ModelCuratorLessons.setLocked(lesson.getLessonId(), locked,
                ViewCuratorLessons.theUser.getUserName())) {
            showMessage("Unable to change the lock. Check Curator permissions.");
            return;
        }
        ViewCuratorLessons.refreshLessons();
        showMessage(locked ? "The lesson was locked." : "The lesson was unlocked.");
    }
    /**
     * <p> Method: showMessage() </p>
     * <p> Description: Displays an information message to the user. </p>
     * @param message the message displayed to the user
     */
    private static void showMessage(String message) {
        new Alert(Alert.AlertType.INFORMATION, message).showAndWait();
    }
    /**
     * <p> Method: performFieldLock() </p>
     * <p> Description: Locks or unlocks a field of the selected lesson. </p>
     * @param field the field to lock or unlock
     * @param locked true to lock the field; false to unlock it
     */
    protected static void performFieldLock(String field, boolean locked) {
        LessonsLearned lesson = ViewCuratorLessons.list_Lessons.getSelectionModel().getSelectedItem();
        if (lesson == null) {
            showMessage("Select a lesson first.");
            return;
        }
        if (!ModelCuratorLessons.setFieldLocked(lesson.getLessonId(), field, locked,
                ViewCuratorLessons.theUser.getUserName())) {
            showMessage("Unable to change the field lock. Check Curator permissions.");
            return;
        }
        ViewCuratorLessons.refreshLessons();
        showMessage(locked ? "Field locked." : "Field unlocked.");
    }

}
