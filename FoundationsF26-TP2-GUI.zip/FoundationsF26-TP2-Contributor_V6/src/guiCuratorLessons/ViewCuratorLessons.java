package guiCuratorLessons;

import entityClasses.LessonsLearned;
import entityClasses.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.text.Font;
import javafx.scene.shape.Line;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/*******
 * <p> Title: ViewCuratorLessons Class. </p>
 * <p> Description: JavaFX Curator lesson review page. The Curator can inspect lessons
 * from all contributors and lock or unlock entire lessons. More detailed Curator epics,
 * including private Curator additions, are planned for TP3. Field-level locking is available here. </p>
 * @version 1.00 2026-10-16 Initial TP2 implementation
 */
public class ViewCuratorLessons {

    /**
     * Constructs a ViewCuratorLessons object.
     */
    public ViewCuratorLessons() {
    }

    // Attributes used by the lesson management page.
    protected static Stage theStage;
    protected static User theUser;
    protected static ListView<LessonsLearned> list_Lessons = new ListView<LessonsLearned>();
    private static TextArea area_Details = new TextArea();
    private static ComboBox<String> box_Field = new ComboBox<String>();

    /*******
     * <p> Method: displayCuratorLessons(Stage ps, User user) </p>
     * <p> Description: Displays the Curator lesson review page. </p>
     * @param ps the JavaFX stage
     * @param user the logged-in Curator
     */
    public static void displayCuratorLessons(Stage ps, User user) {
        theStage = ps;
        theUser = user;
        list_Lessons = new ListView<LessonsLearned>();
        list_Lessons.setCellFactory((_) -> new ListCell<LessonsLearned>() {
            @Override protected void updateItem(LessonsLearned lesson, boolean empty) {
                super.updateItem(lesson, empty);
                setText(empty || lesson == null ? null : lesson.getTitle() + " - " +
                        lesson.getCreatedBy() + (lesson.getLocked() ? " (Locked)" : ""));
            }
        });
        list_Lessons.getSelectionModel().selectedItemProperty().addListener((_, _, lesson) -> {
            if (lesson == null) area_Details.clear();
            else area_Details.setText("Title: " + lesson.getTitle() + "\nContributor: " +
                    lesson.getCreatedBy() + "\nCategory: " + lesson.getCategory() +
                    "\nTags: " + lesson.getTags() + "\nLocked: " + lesson.getLocked() +
                    "\nLocked fields: " + lesson.getLockedFields() +
                    "\n\n" + lesson.getDescription());
        });
        area_Details.setEditable(false);
        area_Details.setWrapText(true);
        Button button_Lock = new Button("Lock Lesson");
        button_Lock.setOnAction((_) -> ControllerCuratorLessons.performLock(true));
        Button button_Unlock = new Button("Unlock Lesson");
        button_Unlock.setOnAction((_) -> ControllerCuratorLessons.performLock(false));
        box_Field.getItems().setAll("title", "description", "category", "tags");
        box_Field.setValue("title");
        Button button_LockField = new Button("Lock Field");
        button_LockField.setOnAction((_) -> ControllerCuratorLessons.performFieldLock(box_Field.getValue(), true));
        Button button_UnlockField = new Button("Unlock Field");
        button_UnlockField.setOnAction((_) -> ControllerCuratorLessons.performFieldLock(box_Field.getValue(), false));
        Button button_Back = new Button("Back to Curator Home");
        button_Back.setOnAction((_) -> guiRole2.ViewRole2Home.displayRole2Home(theStage, theUser));
        // Match the original Foundations role home page: title, user, separators, and footer.
        double width = applicationMain.FoundationsMain.WINDOW_WIDTH;
        double height = applicationMain.FoundationsMain.WINDOW_HEIGHT;
        Pane root = new Pane();
        Label pageTitle = new Label("Curator Lessons");
        pageTitle.setFont(Font.font("Arial", 28));
        pageTitle.setPrefWidth(width);
        pageTitle.setAlignment(Pos.CENTER);
        pageTitle.setLayoutY(5);
        Label userDetails = new Label("User: " + user.getUserName());
        userDetails.setFont(Font.font("Arial", 20));
        userDetails.setLayoutX(20);
        userDetails.setLayoutY(55);
        Button accountUpdate = new Button("Account Update");
        accountUpdate.setFont(Font.font("Dialog", 18));
        accountUpdate.setPrefWidth(170);
        accountUpdate.setLayoutX(width - 190);
        accountUpdate.setLayoutY(45);
        accountUpdate.setOnAction((_) -> guiUserUpdate.ViewUserUpdate.displayUserUpdate(theStage, theUser));
        Line topLine = new Line(20, 95, width - 20, 95);
        Line bottomLine = new Line(20, height - 75, width - 20, height - 75);
        Label lessonsHeading = new Label("All Contributor Lessons");
        lessonsHeading.setFont(Font.font("Arial", 17));
        list_Lessons.setPrefHeight(160);
        area_Details.setPrefHeight(165);
        VBox content = new VBox(10, lessonsHeading, list_Lessons, area_Details,
                new HBox(10, button_Lock, button_Unlock),
                new HBox(10, new Label("Field"), box_Field, button_LockField, button_UnlockField));
        content.setPadding(new Insets(12));
        ScrollPane scroll = new ScrollPane(content);
        scroll.setLayoutX(20);
        scroll.setLayoutY(110);
        scroll.setPrefWidth(width - 40);
        scroll.setPrefHeight(height - 200);
        scroll.setFitToWidth(true);
        button_Back.setFont(Font.font("Dialog", 18));
        button_Back.setPrefWidth(280);
        button_Back.setLayoutX(20);
        button_Back.setLayoutY(height - 60);
        root.getChildren().addAll(pageTitle, userDetails, accountUpdate, topLine,
                scroll, bottomLine, button_Back);
        theStage.setTitle("CSE 360 Foundations: Curator Lessons");
        theStage.setScene(new Scene(root, width, height));
        theStage.show();
        refreshLessons();
    }
    /** <p> Method: refreshLessons() </p> <p> Description: Reloads the lessons after a change. </p> */
    protected static void refreshLessons() {
        list_Lessons.getItems().setAll(ModelCuratorLessons.getLessons(theUser.getUserName()).getLessons());
        area_Details.clear();
    }
}
