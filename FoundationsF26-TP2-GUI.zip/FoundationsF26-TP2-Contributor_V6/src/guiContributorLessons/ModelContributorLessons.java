package guiContributorLessons;

import database.Database;
import entityClasses.LessonsLearned;
import entityClasses.LessonsLearnedList;
import entityClasses.LessonExperience;
import java.util.List;

/*******
 * <p> Title: ModelContributorLessons Class. </p>
 * <p> Description: Provides the Contributor GUI with the database operations for lessons and
 * experiences. The current username is passed to the database for ownership checks. </p>
 * @version 1.00 2026-10-16 Initial TP2 implementation
 */
public class ModelContributorLessons {

    /**
     * Constructs a ModelContributorLessons object.
     */
    public ModelContributorLessons() {
    }

    private static Database theDatabase = applicationMain.FoundationsMain.database;

    /**
     * <p> Method: getLessons() </p>
     * <p> Description: Returns the lessons available to the current user. </p>
     * @param username the logged-in Contributor
     * @return only this Contributor's lessons
     */
    protected static LessonsLearnedList getLessons(String username) {
        return theDatabase.getLessonsForContributor(username);
    }
    /**
     * <p> Method: createLesson() </p>
     * <p> Description: Saves a new lesson through the database. </p>
     * @param lesson the new lesson
     * @return true when saved
     */
    protected static boolean createLesson(LessonsLearned lesson) {
        return theDatabase.createLesson(lesson);
    }
    /**
     * <p> Method: updateLesson() </p>
     * <p> Description: Updates an existing lesson after database ownership and lock checks. </p>
     * @param lesson the edited lesson
     * @param username the owner
     * @return true when saved
     */
    protected static boolean updateLesson(LessonsLearned lesson, String username) {
        return theDatabase.updateLesson(lesson, username);
    }
    /**
     * <p> Method: deleteLesson() </p>
     * <p> Description: Deletes a lesson after database ownership and lock checks. </p>
     * @param lessonId the lesson to remove
     * @param username the owner
     * @return true when deleted
     */
    protected static boolean deleteLesson(int lessonId, String username) {
        return theDatabase.deleteLesson(lessonId, username);
    }
    /**
     * <p> Method: addExperience() </p>
     * <p> Description: Saves an experience associated with a lesson. </p>
     * @param experience an experience record
     * @param username the owner
     * @return true when saved
     */
    protected static boolean addExperience(LessonExperience experience, String username) {
        return theDatabase.addLessonExperience(experience, username);
    }
    /**
     * <p> Method: getExperiences() </p>
     * <p> Description: Returns the recorded experiences for a lesson. </p>
     * @param lessonId the selected lesson
     * @param username the owner
     * @return recorded experiences
     */
    protected static List<LessonExperience> getExperiences(int lessonId, String username) {
        return theDatabase.getLessonExperiences(lessonId, username);
    }
}
