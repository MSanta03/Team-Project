package guiContributorLessons;

import entityClasses.LessonsLearned;
import entityClasses.LessonExperience;
import entityClasses.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.text.Font;
import javafx.scene.shape.Line;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/*******
 * <p> Title: ViewContributorLessons Class. </p>
 * <p> Description: JavaFX Contributor lessons page. The page shows only lessons belonging
 * to the logged-in Contributor and allows creating, editing, deleting and recording experiences.
 * The View holds the widgets; the Controller handles events; the Model accesses the database. </p>
 * @version 1.00 2026-10-16 Initial TP2 implementation
 */
public class ViewContributorLessons {

    /**
     * Constructs a ViewContributorLessons object.
     */
    public ViewContributorLessons() {
    }

    // Attributes used by the lesson management page.
    protected static Stage theStage;
    protected static User theUser;
    protected static LessonsLearned selectedLesson;
    protected static ListView<LessonsLearned> list_Lessons = new ListView<LessonsLearned>();
    protected static TextField field_Title = new TextField();
    protected static TextArea area_Description = new TextArea();
    protected static ComboBox<String> box_Category = new ComboBox<String>();
    protected static TextField field_Tags = new TextField();
    protected static Label label_LockStatus = new Label();
    protected static TextArea area_What = new TextArea();
    protected static TextArea area_How = new TextArea();
    protected static TextField field_Minutes = new TextField();
    protected static TextField field_Effort = new TextField();
    protected static ListView<LessonExperience> list_Experiences = new ListView<LessonExperience>();

    /*******
     * <p> Method: displayContributorLessons(Stage ps, User user) </p>
     * <p> Description: Displays the Contributor lesson management page. </p>
     * @param ps the application's primary stage
     * @param user the logged-in Contributor
     */
    public static void displayContributorLessons(Stage ps, User user) {
        theStage = ps;
        theUser = user;
        selectedLesson = null;
        list_Lessons = new ListView<LessonsLearned>();
        list_Lessons.setPrefWidth(245);
        list_Lessons.setCellFactory((_) -> new ListCell<LessonsLearned>() {
            @Override protected void updateItem(LessonsLearned lesson, boolean empty) {
                super.updateItem(lesson, empty);
                setText(empty || lesson == null ? null : lesson.getTitle() +
                        (lesson.getLocked() ? " (Locked)" : ""));
            }
        });
        list_Lessons.getSelectionModel().selectedItemProperty().addListener((_, _, newValue) -> {
            selectedLesson = newValue;
            populateForm();
        });
        box_Category.getItems().setAll("General", "Technical", "Teamwork", "Project Management",
                "Communication", "Research", "Career");
        area_Description.setPrefRowCount(4);
        area_What.setPrefRowCount(2);
        area_How.setPrefRowCount(2);
        list_Experiences = new ListView<LessonExperience>();
        list_Experiences.setPrefHeight(90);
        list_Experiences.setCellFactory((_) -> new ListCell<LessonExperience>() {
            @Override protected void updateItem(LessonExperience item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getWhatWasDone() + " (" +
                        item.getTimeTakenMinutes() + " minutes, effort " + item.getEffortUsed() + ")");
            }
        });
        // Selecting a saved experience shows its complete details without changing the record.
        list_Experiences.getSelectionModel().selectedItemProperty().addListener((_, _, newValue) -> {
            if (newValue == null) {
                return;
            }
            area_What.setText(newValue.getWhatWasDone());
            area_How.setText(newValue.getHowItWasDone());
            field_Minutes.setText(Integer.toString(newValue.getTimeTakenMinutes()));
            field_Effort.setText(Double.toString(newValue.getEffortUsed()));
            setExperienceReadOnly(true);
        });
        Button button_New = new Button("New Lesson");
        button_New.setOnAction((_) -> clearForm());
        Button button_Save = new Button("Save Lesson");
        button_Save.setOnAction((_) -> ControllerContributorLessons.performSave());
        Button button_Delete = new Button("Delete Lesson");
        button_Delete.setOnAction((_) -> ControllerContributorLessons.performDelete());
        Button button_NewExperience = new Button("New Experience");
        button_NewExperience.setOnAction((_) -> clearExperience());
        Button button_Experience = new Button("Add Experience");
        button_Experience.setOnAction((_) -> ControllerContributorLessons.performExperience());
        Button button_Back = new Button("Back to Contributor Home");
        button_Back.setOnAction((_) -> guiRole1.ViewRole1Home.displayRole1Home(theStage, theUser));
        // Use the same three-area Pane layout as the original Foundations role home pages.
        double width = applicationMain.FoundationsMain.WINDOW_WIDTH;
        double height = applicationMain.FoundationsMain.WINDOW_HEIGHT;
        Pane root = new Pane();
        Label pageTitle = new Label("Contributor Lessons");
        pageTitle.setFont(Font.font("Arial", 28));
        pageTitle.setPrefWidth(width);
        pageTitle.setAlignment(Pos.CENTER);
        pageTitle.setLayoutY(5);
        Label userDetails = new Label("User: " + user.getUserName());
        userDetails.setFont(Font.font("Arial", 20));
        userDetails.setLayoutX(20);
        userDetails.setLayoutY(55);
        Button accountUpdate = new Button("Account Update");
        accountUpdate.setFont(Font.font("Dialog", 18));
        accountUpdate.setPrefWidth(170);
        accountUpdate.setLayoutX(width - 190);
        accountUpdate.setLayoutY(45);
        accountUpdate.setOnAction((_) -> guiUserUpdate.ViewUserUpdate.displayUserUpdate(theStage, theUser));
        Line topLine = new Line(20, 95, width - 20, 95);
        Line bottomLine = new Line(20, height - 75, width - 20, height - 75);

        Label lessonsHeading = new Label("My Lessons");
        lessonsHeading.setFont(Font.font("Arial", 17));
        VBox left = new VBox(10, lessonsHeading, list_Lessons, button_New);
        left.setPrefWidth(235);
        list_Lessons.setPrefHeight(530);
        button_New.setPrefWidth(180);
        VBox details = new VBox(7, new Label("Title"), field_Title, new Label("Description / Lesson Learned"),
                area_Description, new Label("Category"), box_Category, new Label("Tags (comma separated)"),
                field_Tags, label_LockStatus, new HBox(10, button_Save, button_Delete),
                new Separator(), new Label("Experience Using This Lesson"), new Label("What was done"),
                area_What, new Label("How it was done"), area_How,
                new HBox(10, new Label("Minutes"), field_Minutes, new Label("Effort"), field_Effort),
                new HBox(10, button_NewExperience, button_Experience), new Label("Previous Experiences"), list_Experiences);
        details.setPrefWidth(480);
        details.setPadding(new Insets(0, 10, 12, 0));
        HBox content = new HBox(18, left, details);
        content.setPadding(new Insets(12));
        ScrollPane scroll = new ScrollPane(content);
        scroll.setLayoutX(20);
        scroll.setLayoutY(110);
        scroll.setPrefWidth(width - 40);
        scroll.setPrefHeight(height - 200);
        scroll.setFitToWidth(true);
        button_Back.setFont(Font.font("Dialog", 18));
        button_Back.setPrefWidth(280);
        button_Back.setLayoutX(20);
        button_Back.setLayoutY(height - 60);
        root.getChildren().addAll(pageTitle, userDetails, accountUpdate, topLine,
                scroll, bottomLine, button_Back);
        theStage.setTitle("CSE 360 Foundations: Contributor Lessons");
        theStage.setScene(new Scene(root, width, height));
        theStage.show();
        refreshLessons();
        clearForm();
    }

    /** <p> Method: refreshLessons() </p> <p> Description: Reloads the Contributor's own lessons. </p> */
    protected static void refreshLessons() {
        list_Lessons.getItems().setAll(ModelContributorLessons.getLessons(theUser.getUserName()).getLessons());
    }

    /** <p> Method: populateForm() </p> <p> Description: Shows the selected lesson and its lock state. </p> */
    private static void populateForm() {
        if (selectedLesson == null) {
            return;
        }
        clearExperience();
        field_Title.setText(selectedLesson.getTitle());
        area_Description.setText(selectedLesson.getDescription());
        box_Category.setValue(selectedLesson.getCategory());
        field_Tags.setText(selectedLesson.getTags());
        boolean locked = selectedLesson.getLocked();
        boolean anyFieldLocked = !selectedLesson.getLockedFields().isEmpty();
        label_LockStatus.setText(locked ? "Locked: this lesson cannot be edited or deleted." :
                anyFieldLocked ? "Some fields locked: " + selectedLesson.getLockedFields() +
                ". This lesson cannot be deleted." : "Editable");
        field_Title.setDisable(selectedLesson.isFieldLocked("title"));
        area_Description.setDisable(selectedLesson.isFieldLocked("description"));
        box_Category.setDisable(selectedLesson.isFieldLocked("category"));
        field_Tags.setDisable(selectedLesson.isFieldLocked("tags"));
        refreshExperiences();
    }

    /** <p> Method: clearForm() </p> <p> Description: Prepares the form for a new lesson. </p> */
    protected static void clearForm() {
        selectedLesson = null;
        list_Lessons.getSelectionModel().clearSelection();
        field_Title.clear(); area_Description.clear(); field_Tags.clear();
        box_Category.setValue("General");
        field_Title.setDisable(false); area_Description.setDisable(false);
        box_Category.setDisable(false); field_Tags.setDisable(false);
        label_LockStatus.setText("New lesson");
        list_Experiences.getItems().clear();
        clearExperience();
    }

    /** <p> Method: refreshExperiences() </p>
     * <p> Description: Lists the saved experience objects for the selected lesson. Keeping
     * the objects in the list allows the Contributor to view all saved fields. </p> */
    protected static void refreshExperiences() {
        list_Experiences.getItems().clear();
        if (selectedLesson == null) {
            return;
        }
        list_Experiences.getItems().setAll(ModelContributorLessons.getExperiences(
                selectedLesson.getLessonId(), theUser.getUserName()));
    }

    /** <p> Method: setExperienceReadOnly(boolean readOnly) </p>
     * <p> Description: Prevents saved experience details from being edited in the new
     * experience form. The New Experience button enables the fields again. </p>
     * @param readOnly true when viewing a saved experience
     */
    private static void setExperienceReadOnly(boolean readOnly) {
        area_What.setEditable(!readOnly);
        area_How.setEditable(!readOnly);
        field_Minutes.setEditable(!readOnly);
        field_Effort.setEditable(!readOnly);
    }

    /** <p> Method: clearExperience() </p>
     * <p> Description: Clears the experience fields and prepares a new entry. </p> */
    protected static void clearExperience() {
        list_Experiences.getSelectionModel().clearSelection();
        setExperienceReadOnly(false);
        area_What.clear(); area_How.clear(); field_Minutes.clear(); field_Effort.clear();
    }
}
