package guiContributorLessons;

import entityClasses.LessonsLearned;
import entityClasses.LessonExperience;
import lessonLearnedRecognizer.LessonLearnedRecognizer;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

/*******
 * <p> Title: ControllerContributorLessons Class. </p>
 * <p> Description: Handles the Contributor's create, read, update, delete and experience
 * actions. Validation errors are displayed before the database is changed. </p>
 * @version 1.00 2026-10-16 Initial TP2 implementation
 */
public class ControllerContributorLessons {
	
	/**
	 * Constructs a ControllerContributorLessons object.
	 */
	public ControllerContributorLessons() {
	}
	
    /** <p> Method: performSave() </p> <p> Description: Validates and saves the lesson form. </p> */
    protected static void performSave() {
        String title = ViewContributorLessons.field_Title.getText().trim();
        String description = ViewContributorLessons.area_Description.getText().trim();
        String category = ViewContributorLessons.box_Category.getValue();
        String tags = ViewContributorLessons.field_Tags.getText().trim();
        String error = LessonLearnedRecognizer.checkLesson(title, description, category, tags);
        if (!error.isEmpty()) {
            showMessage(error);
            return;
        }
        LessonsLearned lesson = ViewContributorLessons.selectedLesson;
        boolean success;
        if (lesson == null) {
            lesson = new LessonsLearned(title, description, category, tags,
                    ViewContributorLessons.theUser.getUserName());
            success = ModelContributorLessons.createLesson(lesson);
        } else {
            // A locked lesson cannot be edited by its Contributor.
            if (lesson.getLocked()) {
                showMessage("This lesson is locked.");
                return;
            }
            lesson.setTitle(title);
            lesson.setDescription(description);
            lesson.setCategory(category);
            lesson.setTags(tags);
            success = ModelContributorLessons.updateLesson(lesson,
                    ViewContributorLessons.theUser.getUserName());
        }
        if (!success) {
            showMessage("The lesson could not be saved.");
            return;
        }
        ViewContributorLessons.refreshLessons();
        ViewContributorLessons.clearForm();
        showMessage("The lesson was saved.");
    }

    /** <p> Method: performDelete() </p> <p> Description: Confirms deletion of an unlocked lesson. </p> */
    protected static void performDelete() {
        LessonsLearned lesson = ViewContributorLessons.selectedLesson;
        if (lesson == null) {
            showMessage("Select a lesson first.");
            return;
        }
        if (lesson.getLocked() || !lesson.getLockedFields().isEmpty()) {
            showMessage("This lesson or one of its fields is locked and cannot be deleted.");
            return; }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete this lesson? This cannot be undone.", ButtonType.YES, ButtonType.NO);
        if (confirm.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) {
            return;
        }
        if (!ModelContributorLessons.deleteLesson(lesson.getLessonId(),
                ViewContributorLessons.theUser.getUserName())) {
            showMessage("The lesson could not be deleted.");
            return;
        }
        ViewContributorLessons.refreshLessons();
        ViewContributorLessons.clearForm();
    }

    /** <p> Method: performExperience() </p> <p> Description: Adds a record of using the selected lesson. </p> */
    protected static void performExperience() {
        LessonsLearned lesson = ViewContributorLessons.selectedLesson;
        if (lesson == null) {
            showMessage("Select a lesson first.");
            return;
        }
        // A saved experience is for viewing only. Start a new entry before adding another.
        if (ViewContributorLessons.list_Experiences.getSelectionModel().getSelectedItem() != null) {
            showMessage("Click New Experience before adding another experience.");
            return;
        }
        try {
            int minutes = Integer.parseInt(ViewContributorLessons.field_Minutes.getText().trim());
            double effort = Double.parseDouble(ViewContributorLessons.field_Effort.getText().trim());
            String what = ViewContributorLessons.area_What.getText().trim();
            String how = ViewContributorLessons.area_How.getText().trim();
            String error = LessonLearnedRecognizer.checkExperience(what, how, minutes, effort);
            if (!error.isEmpty()) {
                showMessage(error);
                return;
            }
            LessonExperience experience = new LessonExperience(lesson.getLessonId(), what, how, minutes, effort);
            if (ModelContributorLessons.addExperience(experience,
                    ViewContributorLessons.theUser.getUserName())) {
                ViewContributorLessons.refreshExperiences();
                ViewContributorLessons.clearExperience();
                showMessage("The experience was saved.");
            } else showMessage("The experience could not be saved.");
        } catch (NumberFormatException e) {
            showMessage("Enter a valid number for minutes and effort.");
        }
    }

    /**
     * <p> Method: showMessage() </p>
     * <p> Description: Displays an information message to the user. </p>
     * @param message the information displayed to the user
     */
    protected static void showMessage(String message) {
        new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK).showAndWait();
    }
}
