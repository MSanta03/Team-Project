package entityClasses;

import java.util.ArrayList;
import java.util.List;

/*******
 * <p> Title: LessonsLearnedList Class </p>
 * 
 * <p> Description: This class represents a collection of zero, one, or many LessonsLearned
 * entity objects and provides basic operations needed to work with that collection. </p>
 * 
 * <p> Copyright: Jacob Yates © 2026 </p>
 * 
 * @author Jacob Yates
 * 
 * @version 1.00		2026-10-05 Initial implementation for HW2
 */
public class LessonsLearnedList {
	
	private List<LessonsLearned> lessons = new ArrayList<LessonsLearned>();

	/*****
	 * <p> Method: LessonsLearnedList() </p>
	 * <p> Description: Default constructor that establishes an empty collection of lessons. </p>
	 */
	public LessonsLearnedList() {
	}

	/*****
	 * <p> Method: LessonsLearnedList(List&lt;LessonsLearned&gt; lessons) </p>
	 * <p> Description: Constructor that establishes a collection using the supplied lessons. </p>
	 * @param lessons specifies the lessons to place in the collection
	 */
	public LessonsLearnedList(List<LessonsLearned> lessons) {
		if (lessons != null) this.lessons.addAll(lessons);
	}

	/*****
	 * <p> Method: addLesson(LessonsLearned lesson) </p>
	 * <p> Description: Adds a non-null lesson to this collection. </p>
	 * @param lesson specifies the lesson to add
	 */
	public void addLesson(LessonsLearned lesson) {
		if (lesson != null) lessons.add(lesson);
	}

	/*****
	 * <p> Method: getLesson(int lessonId) </p>
	 * <p> Description: Searches this collection for the lesson with the specified identifier. </p>
	 * @param lessonId specifies the lesson identifier to locate
	 * @return the matching lesson, or null when no matching lesson exists
	 */
	public LessonsLearned getLesson(int lessonId) {
		for (LessonsLearned lesson : lessons)
			if (lesson.getLessonId() == lessonId) return lesson;
		return null;
	}

	/*****
	 * <p> Method: removeLesson(int lessonId) </p>
	 * <p> Description: Removes an unlocked lesson with the specified identifier from this collection. </p>
	 * @param lessonId specifies the lesson identifier to remove
	 * @return true when the lesson was removed; otherwise false
	 */
	public boolean removeLesson(int lessonId) {
		LessonsLearned lesson = getLesson(lessonId);
		if (lesson == null || lesson.getLocked()) return false;
		return lessons.remove(lesson);
	}

	/*****
	 * <p> Method: size() </p>
	 * <p> Description: Returns the number of lessons currently stored in this collection. </p>
	 * @return the number of lessons
	 */
	public int size() { return lessons.size(); }

	/*****
	 * <p> Method: getLessons() </p>
	 * <p> Description: Returns a copy of the list of lessons so callers cannot directly modify the internal list. </p>
	 * @return a copy of the lesson list
	 */
	public List<LessonsLearned> getLessons() {
		return new ArrayList<LessonsLearned>(lessons);
	}
}
