package database;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import entityClasses.User;
import entityClasses.LessonsLearned;
import entityClasses.LessonsLearnedList;
import entityClasses.LessonExperience;
import lessonLearnedRecognizer.LessonLearnedRecognizer;

/*******
 * <p> Title: Database Class. </p>
 * 
 * <p> Description: This is an in-memory database built on H2.  Detailed documentation of H2 can
 * be found at https://www.h2database.com/html/main.html (Click on "PDF (2MB)" on the l3ft side
 * of the page under the heading "Reference" for a PDF of 438 pages.)  This class leverages H2
 * and provides numerous special supporting methods.
 * </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2025 </p>
 * 
 * @author Jacob Yates
 * 
 * @version 2.00		2025-04-29 Updated and expanded from the version produce by Pravalika 
 * 							Mukkiri and Ishwarya Hidkimath Basavaraj
 * @version 2.01		2025-12-17 Minor updates for Spring 2026
 * 
 * @version 2.02		2026-09-13 Added all logic for One Time Passwords - 
 * 								   Added oneTimePassword to userDB, setOneTimePassword(), isValidOneTimePassword(),
 * 								   clearOneTimePassword(), updatePassword()
 * @version 2.03		2026-09-13 Updated getUserAccountDetails to search by name instead of row number
 * 								   due to bug caused when adding One time password table to DB
 */

/*
 * The Database class is responsible for establishing and managing the connection to the database,
 * and performing operations such as user registration, login validation, handling invitation 
 * codes, and numerous other database related functions.
 */
public class Database {

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	//  Shared variables used within this class
	private Connection connection = null;		// Singleton to access the database 
	private Statement statement = null;			// The H2 Statement is used to construct queries
	
	// These are the easily accessible attributes of the currently logged-in user
	// This is only useful for single user applications
	private String currentUsername;
	private String currentPassword;
	private String currentFirstName;
	private String currentMiddleName;
	private String currentLastName;
	private String currentPreferredFirstName;
	private String currentEmailAddress;
	private boolean currentAdminRole;
	private boolean currentNewRole1;
	private boolean currentNewRole2;

	/*******
	 * <p> Method: Database </p>
	 * 
	 * <p> Description: The default constructor used to establish this singleton object.</p>
	 * 
	 */
	
	public Database () {
		
	}
	
	
/*******
 * <p> Method: connectToDatabase </p>
 * 
 * <p> Description: Used to establish the in-memory instance of the H2 database from secondary
 *		storage.</p>
 *
 * @throws SQLException when the DriverManager is unable to establish a connection
 * 
 */
	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement(); 
			// You can use this command to clear the database and restart from fresh.
			//statement.execute("DROP ALL OBJECTS");

			createTables();  // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	
/*******
 * <p> Method: createTables </p>
 * 
 * <p> Description: Used to create new instances of the two database tables used by this class.</p>
 * 
 */
	private void createTables() throws SQLException {
		// Create the user database
		String userTable = "CREATE TABLE IF NOT EXISTS userDB ("
				+ "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userName VARCHAR(255) UNIQUE, "
				+ "password VARCHAR(255), "
				+ "oneTimePassword VARCHAR(255), "
				+ "firstName VARCHAR(255), "
				+ "middleName VARCHAR(255), "
				+ "lastName VARCHAR (255), "
				+ "preferredFirstName VARCHAR(255), "
				+ "emailAddress VARCHAR(255), "
				+ "adminRole BOOL DEFAULT FALSE, "
				+ "newRole1 BOOL DEFAULT FALSE, "
				+ "newRole2 BOOL DEFAULT FALSE)";
		statement.execute(userTable);
		
		// Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(10) PRIMARY KEY, "
	    		+ "emailAddress VARCHAR(255), "
	            + "role VARCHAR(20))";
	    statement.execute(invitationCodesTable);
        // Older TP1 databases used VARCHAR(10), which is too short for Contributor.
        statement.execute("ALTER TABLE invitationCodes ALTER COLUMN role VARCHAR(20)");

		// Create the Lessons Learned table
		String lessonsLearnedTable = "CREATE TABLE IF NOT EXISTS LessonsLearned ("
				+ "lessonId INT AUTO_INCREMENT PRIMARY KEY, "
				+ "title VARCHAR(100) NOT NULL, "
				+ "description VARCHAR(2000) NOT NULL, "
				+ "category VARCHAR(50) NOT NULL, "
				+ "tags VARCHAR(255), "
				+ "createdBy VARCHAR(255) NOT NULL, "
				+ "dateCreated DATE NOT NULL, "
				+ "locked BOOL DEFAULT FALSE)";
		statement.execute(lessonsLearnedTable);
        // Migration for existing HW2 databases. A field lock is independent of a whole-lesson lock. Adding in "Alter" to help with always having to 
		// delete the database on new iterations of the program
        statement.execute("ALTER TABLE LessonsLearned ADD COLUMN IF NOT EXISTS lockedFields VARCHAR(255) DEFAULT ''");
        // Each experience belongs to a lesson. The contributor is checked when it is saved.
        statement.execute("CREATE TABLE IF NOT EXISTS LessonExperiences (" +
                "experienceId INT AUTO_INCREMENT PRIMARY KEY, lessonId INT NOT NULL, " +
                "whatWasDone VARCHAR(2000) NOT NULL, howItWasDone VARCHAR(2000) NOT NULL, " +
                "timeTakenMinutes INT NOT NULL, effortUsed DOUBLE NOT NULL)");
	}


/*******
 * <p> Method: isDatabaseEmpty </p>
 * 
 * <p> Description: If the user database has no rows, true is returned, else false.</p>
 * 
 * @return true if the database is empty, else it returns false
 * 
 */
	public boolean isDatabaseEmpty() {
		String query = "SELECT COUNT(*) AS count FROM userDB";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count") == 0;
			}
		}  catch (SQLException e) {
	        return false;
	    }
		return true;
	}
	
	
/*******
 * <p> Method: getNumberOfUsers </p>
 * 
 * <p> Description: Returns an integer .of the number of users currently in the user database. </p>
 * 
 * @return the number of user records in the database.
 * 
 */
	public int getNumberOfUsers() {
		String query = "SELECT COUNT(*) AS count FROM userDB";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count");
			}
		} catch (SQLException e) {
	        return 0;
	    }
		return 0;
	}

/*******
 * <p> Method: register(User user) </p>
 * 
 * <p> Description: Creates a new row in the database using the user parameter. </p>
 * 
 * @throws SQLException when there is an issue creating the SQL command or executing it.
 * 
 * @param user specifies a user object to be added to the database.
 * 
 */
	public void register(User user) throws SQLException {
		String insertUser = "INSERT INTO userDB (userName, password, firstName, middleName, "
				+ "lastName, preferredFirstName, emailAddress, adminRole, newRole1, newRole2) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			currentUsername = user.getUserName();
			pstmt.setString(1, currentUsername);
			
			currentPassword = user.getPassword();
			pstmt.setString(2, currentPassword);
			
			currentFirstName = user.getFirstName();
			pstmt.setString(3, currentFirstName);
			
			currentMiddleName = user.getMiddleName();			
			pstmt.setString(4, currentMiddleName);
			
			currentLastName = user.getLastName();
			pstmt.setString(5, currentLastName);
			
			currentPreferredFirstName = user.getPreferredFirstName();
			pstmt.setString(6, currentPreferredFirstName);
			
			currentEmailAddress = user.getEmailAddress();
			pstmt.setString(7, currentEmailAddress);
			
			currentAdminRole = user.getAdminRole();
			pstmt.setBoolean(8, currentAdminRole);
			
			currentNewRole1 = user.getNewRole1();
			pstmt.setBoolean(9, currentNewRole1);
			
			currentNewRole2 = user.getNewRole2();
			pstmt.setBoolean(10, currentNewRole2);
			
			pstmt.executeUpdate();
		}
		
	}
	
/*******
 *  <p> Method: List getUserList() </p>
 *  
 *  <P> Description: Generate an List of Strings, one for each user in the database,
 *  starting with "{@code <Select User>}" at the start of the list. </p>
 *  
 *  @return a list of userNames found in the database.
 */
	public List<String> getUserList () {
		List<String> userList = new ArrayList<String>();
		userList.add("<Select a User>");
		String query = "SELECT userName FROM userDB";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				userList.add(rs.getString("userName"));
			}
		} catch (SQLException e) {
	        return null;
	    }
//		System.out.println(userList);
		return userList;
	}

/*******
 * <p> Method: boolean loginAdmin(User user) </p>
 * 
 * <p> Description: Check to see that a user with the specified username, password, and role
 * 		is the same as a row in the table for the username, password, and role. </p>
 * 
 * @param user specifies the specific user that should be logged in playing the Admin role.
 * 
 * @return true if the specified user has been logged in as an Admin else false.
 * 
 */
	public boolean loginAdmin(User user){
		// Validates an admin user's login credentials so the user can login in as an Admin.
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND "
				+ "adminRole = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();	// If a row is returned, rs.next() will return true		
		} catch  (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}
	
	
/*******
 * <p> Method: boolean loginRole1(User user) </p>
 * 
 * <p> Description: Check to see that a user with the specified username, password, and role
 * 		is the same as a row in the table for the username, password, and role. </p>
 * 
 * @param user specifies the specific user that should be logged in playing the Student role.
 * 
 * @return true if the specified user has been logged in as an Student else false.
 * 
 */
	public boolean loginRole1(User user) {
		// Validates a student user's login credentials.
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND "
				+ "newRole1 = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		} catch  (SQLException e) {
		       e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p> Method: boolean loginRole2(User user) </p>
	 * 
	 * <p> Description: Check to see that a user with the specified username, password, and role
	 * 		is the same as a row in the table for the username, password, and role. </p>
	 * 
	 * @param user specifies the specific user that should be logged in playing the Reviewer role.
	 * 
	 * @return true if the specified user has been logged in as an Student else false.
	 * 
	 */
	// Validates a reviewer user's login credentials.
	public boolean loginRole2(User user) {
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND "
				+ "newRole2 = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		} catch  (SQLException e) {
		       e.printStackTrace();
		}
		return false;
	}
	
	
	/*******
	 * <p> Method: boolean doesUserExist(User user) </p>
	 * 
	 * <p> Description: Check to see that a user with the specified username is  in the table. </p>
	 * 
	 * @param userName specifies the specific user that we want to determine if it is in the table.
	 * 
	 * @return true if the specified user is in the table else false.
	 * 
	 */
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM userDB WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}

	/******
	 * <p> Method: void deleteUser(String userName) </p>
	 * 
	 * <p> Description: Deletes the specified user account from the user database. </p>
	 * 
	 * @param userName specifies the user that we want to delete.
	 * 
	 */

	public void deleteUser(String userName) {
		
		String query = "DELETE FROM userDB WHERE userName = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	/*******
	 * <p> Method: int getNumberOfRoles(User user) </p>
	 * 
	 * <p> Description: Determine the number of roles a specified user plays. </p>
	 * 
	 * @param user specifies the specific user that we want to determine if it is in the table.
	 * 
	 * @return the number of roles this user plays (0 - 5).
	 * 
	 */	
	// Get the number of roles that this user plays
	public int getNumberOfRoles (User user) {
		int numberOfRoles = 0;
		if (user.getAdminRole()) numberOfRoles++;
		if (user.getNewRole1()) numberOfRoles++;
		if (user.getNewRole2()) numberOfRoles++;
		return numberOfRoles;
	}	

	
	/*******
	 * <p> Method: String generateInvitationCode(String emailAddress, String role) </p>
	 * 
	 * <p> Description: Given an email address and a roles, this method establishes and invitation
	 * code and adds a record to the InvitationCodes table.  When the invitation code is used, the
	 * stored email address is used to establish the new user and the record is removed from the
	 * table.</p>
	 * 
	 * @param emailAddress specifies the email address for this new user.
	 * 
	 * @param role specified the role that this new user will play.
	 * 
	 * @return the code of six characters so the new user can use it to securely setup an account.
	 * 
	 */
	// Generates a new invitation code and inserts it into the database.
	public String generateInvitationCode(String emailAddress, String role) {
	    String code = UUID.randomUUID().toString().substring(0, 6); // Generate a random 6-character code
	    String query = "INSERT INTO InvitationCodes (code, emailaddress, role) VALUES (?, ?, ?)";

	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.setString(2, emailAddress);
	        pstmt.setString(3, role);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return code;
	}

	
	/*******
	 * <p> Method: int getNumberOfInvitations() </p>
	 * 
	 * <p> Description: Determine the number of outstanding invitations in the table.</p>
	 *  
	 * @return the number of invitations in the table.
	 * 
	 */
	// Number of invitations in the database
	public int getNumberOfInvitations() {
		String query = "SELECT COUNT(*) AS count FROM InvitationCodes";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count");
			}
		} catch  (SQLException e) {
	        e.printStackTrace();
	    }
		return 0;
	}
	
	
	/*******
	 * <p> Method: boolean emailaddressHasBeenUsed(String emailAddress) </p>
	 * 
	 * <p> Description: Determine if an email address has been user to establish a user.</p>
	 * 
	 * @param emailAddress is a string that identifies a user in the table
	 *  
	 * @return true if the email address is in the table, else return false.
	 * 
	 */
	// Check to see if an email address is already in the database
	public boolean emailaddressHasBeenUsed(String emailAddress) {
	    String query = "SELECT COUNT(*) AS count FROM InvitationCodes WHERE emailAddress = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, emailAddress);
	        ResultSet rs = pstmt.executeQuery();
	 //     System.out.println(rs);
	        if (rs.next()) {
	            // Mark the code as used
	        	return rs.getInt("count")>0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}
	
	
	/*******
	 * <p> Method: String getRoleGivenAnInvitationCode(String code) </p>
	 * 
	 * <p> Description: Get the role associated with an invitation code.</p>
	 * 
	 * @param code is the 6 character String invitation code
	 *  
	 * @return the role for the code or an empty string.
	 * 
	 */
	// Obtain the roles associated with an invitation code.
	public String getRoleGivenAnInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            return rs.getString("role");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return "";
	}

	
	/*******
	 * <p> Method: String getEmailAddressUsingCode (String code ) </p>
	 * 
	 * <p> Description: Get the email addressed associated with an invitation code.</p>
	 * 
	 * @param code is the 6 character String invitation code
	 *  
	 * @return the email address for the code or an empty string.
	 * 
	 */
	// For a given invitation code, return the associated email address of an empty string
	public String getEmailAddressUsingCode (String code ) {
	    String query = "SELECT emailAddress FROM InvitationCodes WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            return rs.getString("emailAddress");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return "";
	}
	
	
	/*******
	 * <p> Method: void removeInvitationAfterUse(String code) </p>
	 * 
	 * <p> Description: Remove an invitation record once it is used.</p>
	 * 
	 * @param code is the 6 character String invitation code
	 *  
	 */
	// Remove an invitation using an email address once the user account has been setup
	public void removeInvitationAfterUse(String code) {
	    String query = "SELECT COUNT(*) AS count FROM InvitationCodes WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	        	int counter = rs.getInt(1);
	            // Only do the remove if the code is still in the invitation table
	        	if (counter > 0) {
        			query = "DELETE FROM InvitationCodes WHERE code = ?";
	        		try (PreparedStatement pstmt2 = connection.prepareStatement(query)) {
	        			pstmt2.setString(1, code);
	        			pstmt2.executeUpdate();
	        		}catch (SQLException e) {
	        	        e.printStackTrace();
	        	    }
	        	}
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return;
	}
	
	
	/*******
	 * <p> Method: String getFirstName(String username) </p>
	 * 
	 * <p> Description: Get the first name of a user given that user's username.</p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the first name of a user given that user's username 
	 *  
	 */
	// Get the First Name
	public String getFirstName(String username) {
		String query = "SELECT firstName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("firstName"); // Return the first name if user exists
	        }
			
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	

	/*******
	 * <p> Method: void updateFirstName(String username, String firstName) </p>
	 * 
	 * <p> Description: Update the first name of a user given that user's username and the new
	 *		first name.</p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @param firstName is the new first name for the user
	 *  
	 */
	// update the first name
	public void updateFirstName(String username, String firstName) {
	    String query = "UPDATE userDB SET firstName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, firstName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentFirstName = firstName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	/*******
	 * <p> Method: String getMiddleName(String username) </p>
	 * 
	 * <p> Description: Get the middle name of a user given that user's username.</p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the middle name of a user given that user's username 
	 *  
	 */
	// get the middle name
	public String getMiddleName(String username) {
		String query = "SELECT MiddleName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("middleName"); // Return the middle name if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}

	
	/*******
	 * <p> Method: void updateMiddleName(String username, String middleName) </p>
	 * 
	 * <p> Description: Update the middle name of a user given that user's username and the new
	 * 		middle name.</p>
	 * 
	 * @param username is the username of the user
	 *  
	 * @param middleName is the new middle name for the user
	 *  
	 */
	// update the middle name
	public void updateMiddleName(String username, String middleName) {
	    String query = "UPDATE userDB SET middleName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, middleName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentMiddleName = middleName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: String getLastName(String username) </p>
	 * 
	 * <p> Description: Get the last name of a user given that user's username.</p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the last name of a user given that user's username 
	 *  
	 */
	// get he last name
	public String getLastName(String username) {
		String query = "SELECT LastName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("lastName"); // Return last name role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	
	/*******
	 * <p> Method: void updateLastName(String username, String lastName) </p>
	 * 
	 * <p> Description: Update the middle name of a user given that user's username and the new
	 * 		middle name.</p>
	 * 
	 * @param username is the username of the user
	 *  
	 * @param lastName is the new last name for the user
	 *  
	 */
	// update the last name
	public void updateLastName(String username, String lastName) {
	    String query = "UPDATE userDB SET lastName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, lastName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentLastName = lastName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: String getPreferredFirstName(String username) </p>
	 * 
	 * <p> Description: Get the preferred first name of a user given that user's username.</p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the preferred first name of a user given that user's username 
	 *  
	 */
	// get the preferred first name
	public String getPreferredFirstName(String username) {
		String query = "SELECT preferredFirstName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("firstName"); // Return the preferred first name if user exists
	        }
			
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	
	/*******
	 * <p> Method: void updatePreferredFirstName(String username, String preferredFirstName) </p>
	 * 
	 * <p> Description: Update the preferred first name of a user given that user's username and
	 * 		the new preferred first name.</p>
	 * 
	 * @param username is the username of the user
	 *  
	 * @param preferredFirstName is the new preferred first name for the user
	 *  
	 */
	// update the preferred first name of the user
	public void updatePreferredFirstName(String username, String preferredFirstName) {
	    String query = "UPDATE userDB SET preferredFirstName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, preferredFirstName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentPreferredFirstName = preferredFirstName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: String getEmailAddress(String username) </p>
	 * 
	 * <p> Description: Get the email address of a user given that user's username.</p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the email address of a user given that user's username 
	 *  
	 */
	// get the email address
	public String getEmailAddress(String username) {
		String query = "SELECT emailAddress FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("emailAddress"); // Return the email address if user exists
	        }
			
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	
	/*******
	 * <p> Method: void updateEmailAddress(String username, String emailAddress) </p>
	 * 
	 * <p> Description: Update the email address name of a user given that user's username and
	 * 		the new email address.</p>
	 * 
	 * @param username is the username of the user
	 *  
	 * @param emailAddress is the new preferred first name for the user
	 *  
	 */
	// update the email address
	public void updateEmailAddress(String username, String emailAddress) {
	    String query = "UPDATE userDB SET emailAddress = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, emailAddress);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentEmailAddress = emailAddress;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: boolean getUserAccountDetails(String username) </p>
	 * 
	 * <p> Description: Get all the attributes of a user given that user's username.</p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return true of the get is successful, else false
	 *  
	 */
	// get the attributes for a specified user
	public boolean getUserAccountDetails(String username) {
		String query = "SELECT * FROM userDB WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();			
			rs.next();
			currentUsername = rs.getString("userName");
			currentPassword = rs.getString("password");
			currentFirstName = rs.getString("firstName");
			currentMiddleName = rs.getString("middleName");
			currentLastName = rs.getString("lastName");
			currentPreferredFirstName = rs.getString("preferredFirstName");
			currentEmailAddress = rs.getString("emailAddress");
			currentAdminRole = rs.getBoolean("adminRole");
			currentNewRole1 = rs.getBoolean("newRole1");
			currentNewRole2 = rs.getBoolean("newRole2");
			return true;
	    } catch (SQLException e) {
			return false;
	    }
	}
	
	
	/*******
	 * <p> Method: boolean updateUserRole(String username, String role, String value) </p>
	 * 
	 * <p> Description: Update a specified role for a specified user's and set and update all the
	 * 		current user attributes.</p>
	 * 
	 * @param username is the username of the user
	 *  
	 * @param role is string that specifies the role to update
	 * 
	 * @param value is the string that specified TRUE or FALSE for the role
	 * 
	 * @return true if the update was successful, else false
	 *  
	 */
	// Update a users role
	public boolean updateUserRole(String username, String role, String value) {
		if (role.compareTo("Admin") == 0) {
			String query = "UPDATE userDB SET adminRole = ? WHERE username = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setString(1, value);
				pstmt.setString(2, username);
				pstmt.executeUpdate();
				if (value.compareTo("true") == 0)
					currentAdminRole = true;
				else
					currentAdminRole = false;
				return true;
			} catch (SQLException e) {
				return false;
			}
		}
		if (role.compareTo("Role1") == 0 || role.compareTo("Contributor") == 0) {
			String query = "UPDATE userDB SET newRole1 = ? WHERE username = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setString(1, value);
				pstmt.setString(2, username);
				pstmt.executeUpdate();
				if (value.compareTo("true") == 0)
					currentNewRole1 = true;
				else
					currentNewRole1 = false;
				return true;
			} catch (SQLException e) {
				return false;
			}
		}
		if (role.compareTo("Role2") == 0 || role.compareTo("Curator") == 0) {
			String query = "UPDATE userDB SET newRole2 = ? WHERE username = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setString(1, value);
				pstmt.setString(2, username);
				pstmt.executeUpdate();
				if (value.compareTo("true") == 0)
					currentNewRole2 = true;
				else
					currentNewRole2 = false;
				return true;
			} catch (SQLException e) {
				return false;
			}
		}
		return false;
	}
	
	// return all users in the database
	/**
	 * Retrieves all users stored in the database.
	 *
	 * @return a list containing all users
	 */
		public List<User> getAllUsers(){
			List<User> users = new ArrayList<User>();
			String query = "SELECT userName, firstName, middleName, lastName, " + "preferredFirstName, emailAddress, adminRole, newRole1, newRole2 " + "FROM userDB";
			try(PreparedStatement pstmt = connection.prepareStatement(query)){
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					User user = new User();
					
					user.setUserName(rs.getString("userName"));
					user.setFirstName(rs.getString("firstName"));
					user.setMiddleName(rs.getString("middleName"));
					user.setLastName(rs.getString("lastName"));
					user.setPreferredFirstName(rs.getString("preferredFirstName"));
					user.setEmailAddress(rs.getString("emailAddress"));
					
					user.setAdminRole(rs.getBoolean("adminRole"));
					user.setRole1User(rs.getBoolean("newRole1"));
					user.setRole2User(rs.getBoolean("newRole2"));
					
					users.add(user);
					
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return users;
		}
	
	// Attribute getters for the current user
	/*******
	 * <p> Method: String getCurrentUsername() </p>
	 * 
	 * <p> Description: Get the current user's username.</p>
	 * 
	 * @return the username value is returned
	 *  
	 */
	public String getCurrentUsername() { return currentUsername;};

	
	/*******
	 * <p> Method: String getCurrentPassword() </p>
	 * 
	 * <p> Description: Get the current user's password.</p>
	 * 
	 * @return the password value is returned
	 *  
	 */
	public String getCurrentPassword() { return currentPassword;};

	
	/*******
	 * <p> Method: String getCurrentFirstName() </p>
	 * 
	 * <p> Description: Get the current user's first name.</p>
	 * 
	 * @return the first name value is returned
	 *  
	 */
	public String getCurrentFirstName() { return currentFirstName;};

	
	/*******
	 * <p> Method: String getCurrentMiddleName() </p>
	 * 
	 * <p> Description: Get the current user's middle name.</p>
	 * 
	 * @return the middle name value is returned
	 *  
	 */
	public String getCurrentMiddleName() { return currentMiddleName;};

	
	/*******
	 * <p> Method: String getCurrentLastName() </p>
	 * 
	 * <p> Description: Get the current user's last name.</p>
	 * 
	 * @return the last name value is returned
	 *  
	 */
	public String getCurrentLastName() { return currentLastName;};

	
	/*******
	 * <p> Method: String getCurrentPreferredFirstName( </p>
	 * 
	 * <p> Description: Get the current user's preferred first name.</p>
	 * 
	 * @return the preferred first name value is returned
	 *  
	 */
	public String getCurrentPreferredFirstName() { return currentPreferredFirstName;};

	
	/*******
	 * <p> Method: String getCurrentEmailAddress() </p>
	 * 
	 * <p> Description: Get the current user's email address name.</p>
	 * 
	 * @return the email address value is returned
	 *  
	 */
	public String getCurrentEmailAddress() { return currentEmailAddress;};

	
	/*******
	 * <p> Method: boolean getCurrentAdminRole() </p>
	 * 
	 * <p> Description: Get the current user's Admin role attribute.</p>
	 * 
	 * @return true if this user plays an Admin role, else false
	 *  
	 */
	public boolean getCurrentAdminRole() { return currentAdminRole;};

	
	/*******
	 * <p> Method: boolean getCurrentNewRole1() </p>
	 * 
	 * <p> Description: Get the current user's Student role attribute.</p>
	 * 
	 * @return true if this user plays a Student role, else false
	 *  
	 */
	public boolean getCurrentNewRole1() { return currentNewRole1;};

	
	/*******
	 * <p> Method: boolean getCurrentNewRole2() </p>
	 * 
	 * <p> Description: Get the current user's Reviewer role attribute.</p>
	 * 
	 * @return true if this user plays a Reviewer role, else false
	 *  
	 */
	public boolean getCurrentNewRole2() { return currentNewRole2;};

	
	/*******
	 * <p> Debugging method</p>
	 * 
	 * <p> Description: Debugging method that dumps the database of the console.</p>
	 * 
	 * @throws SQLException if there is an issues accessing the database.
	 * 
	 */
	// Dumps the database.
	public void dump() throws SQLException {
		String query = "SELECT * FROM userDB";
		ResultSet resultSet = statement.executeQuery(query);
		ResultSetMetaData meta = resultSet.getMetaData();
		while (resultSet.next()) {
		for (int i = 0; i < meta.getColumnCount(); i++) {
		System.out.println(
		meta.getColumnLabel(i + 1) + ": " +
				resultSet.getString(i + 1));
		}
		System.out.println();
		}
		resultSet.close();
	}


	/*******
	 * <p> Method: void closeConnection()</p>
	 * 
	 * <p> Description: Closes the database statement and connection.</p>
	 * 
	 */
	// Closes the database statement and connection.
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}
	
	
	/*******
	 * <p> Method: boolean setOneTimePassword(String username, String oneTimePassword) </p>
	 * 
	 * <p> Description: Set a one time password for the user associated with the specified username
	 * The one time password is stored separately from the users normal password so the users
	 * permanent password is not changed until the user establishes a new password. </p>
	 * 
	 * @param username specifies the user whose one time password is to be set
	 * 
	 * @param oneTimePassword specifies the temporary password that will be used one time to log in.
	 * 
	 * @return true if the one time password was stored for the specified user, else false.
	 * 
	 */
	public boolean setOneTimePassword(String username, String oneTimePassword) {
		// Store the one-time password for the specified user
		String query = "UPDATE userDB SET oneTimePassword = ? WHERE userName = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, oneTimePassword);
			pstmt.setString(2, username);
			
			int numberOfRowsUpdated = pstmt.executeUpdate();
			
			// One row should be updated when the username exists, meaning the one time password was updated
			return numberOfRowsUpdated == 1;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	

	/*******
	 * <p> Method: boolean isValidOneTimePassword(String username, String oneTimePassword) </p>
	 * 
	 * <p> Description: Determine if the specified one-time password is the active one-time password
	 * associated with the specified username.  The one-time password is user specific.  A one-time
	 * password associated with another username will not be accepted for this user. </p>
	 * 
	 * @param username specifies the user attempting to log in.
	 * 
	 * @param oneTimePassword specifies the password entered by the user.
	 * 
	 * @return true if the specified password is the active one-time password for this user, else false.
	 * 
	 */
	public boolean isValidOneTimePassword(String username, String oneTimePassword) {
		// Fetch only the one-time password that belongs to this username
		String query = "SELECT oneTimePassword FROM userDB WHERE userName = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			
			if (rs.next()) {
				String storedOneTimePassword = rs.getString("oneTimePassword");
				
				// A NULL value means this user does not currently have an active one-time password
				if (storedOneTimePassword == null) {
					return false;
				}
				
				// Compare the entered password with this user's one-time password
				return oneTimePassword.equals(storedOneTimePassword);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	/*******
	 * <p> Method: boolean clearOneTimePassword(String username) </p>
	 * 
	 * <p> Description: Clear the one-time password associated with the specified username.  This
	 * method is used after the user successfully logs in using the one-time password so that the
	 * password cannot be used a second time. </p>
	 * 
	 * @param username specifies the user whose one-time password is to be cleared.
	 * 
	 * @return true if the one-time password was cleared for the specified user, else false.
	 * 
	 */
	public boolean clearOneTimePassword(String username) {
		// Set the user's one-time password to NULL so it can no longer be used
		String query = "UPDATE userDB SET oneTimePassword = NULL WHERE userName = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			
			int numberOfRowsUpdated = pstmt.executeUpdate();
			
			return numberOfRowsUpdated == 1;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	/*******
	 * <p> Method: boolean updatePassword(String username, String newPassword) </p>
	 * 
	 * <p> Description: Replace the permanent password associated with the specified username with
	 * the new password.  This method is used after a user has logged in using a one-time password
	 * and successfully created a valid new permanent password. </p>
	 * 
	 * @param username specifies the user whose permanent password is to be updated.
	 * 
	 * @param newPassword specifies the new permanent password for this user.
	 * 
	 * @return true if the permanent password was updated, else false.
	 * 
	 */
	public boolean updatePassword(String username, String newPassword) {
		// Replace the current permanent password with the new password
		String query = "UPDATE userDB SET password = ? WHERE userName = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, newPassword);
			pstmt.setString(2, username);
			
			int numberOfRowsUpdated = pstmt.executeUpdate();
			
			// Keep the current user information synchronized if this is the current account
			if (numberOfRowsUpdated == 1 && username.equals(currentUsername)) {
				currentPassword = newPassword;
			}
			
			return numberOfRowsUpdated == 1;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	
	
	/*******
	 * <p> Method: boolean createLesson(LessonsLearned lesson) </p>
	 * 
	 * <p> Description: Creates a new Lessons Learned row using the supplied lesson entity. </p>
	 * 
	 * @param lesson specifies the lesson to be added to the database
	 * @return true if the lesson was added, else false
	 */
	public boolean createLesson(LessonsLearned lesson) {
        if (lesson == null || !LessonLearnedRecognizer.checkLesson(
        		lesson.getTitle(),
                lesson.getDescription(),
                lesson.getCategory(),
                lesson.getTags()).isEmpty()) return false;
		String query = "INSERT INTO LessonsLearned (title, description, category, tags, createdBy, dateCreated, locked) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
			pstmt.setString(1, lesson.getTitle());
			pstmt.setString(2, lesson.getDescription());
			pstmt.setString(3, lesson.getCategory());
			pstmt.setString(4, lesson.getTags());
			pstmt.setString(5, lesson.getCreatedBy());
			pstmt.setDate(6, Date.valueOf(lesson.getDateCreated()));
			pstmt.setBoolean(7, lesson.getLocked());
			if (pstmt.executeUpdate() != 1) return false;
			ResultSet keys = pstmt.getGeneratedKeys();
			if (keys.next()) lesson.setLessonId(keys.getInt(1));
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Retrieves a lesson by its ID for the specified user.
	 *
	 * @param lessonId the ID of the lesson to retrieve
	 * @param username the username of the user requesting the lesson
	 * @return the requested lesson, or null if it cannot be retrieved
	 */
	
	public LessonsLearned getLesson(int lessonId, String username) {
		String query = "SELECT * FROM LessonsLearned WHERE lessonId = ? AND createdBy = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, lessonId);
			pstmt.setString(2, username);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) return buildLessonFromResultSet(rs);
		} catch (SQLException e) { e.printStackTrace(); }
		return null;
	}

	/**
	 * Retrieves the lessons associated with a contributor.
	 *
	 * @param username the username of the contributor
	 * @return the list of lessons associated with the contributor
	 */
	public LessonsLearnedList getLessonsForContributor(String username) {
		LessonsLearnedList lessons = new LessonsLearnedList();
		String query = "SELECT * FROM LessonsLearned WHERE createdBy = ? ORDER BY lessonId";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) lessons.addLesson(buildLessonFromResultSet(rs));
		} catch (SQLException e) { e.printStackTrace(); }
		return lessons;
	}

	/**
	 * Updates an existing lesson.
	 *
	 * @param lesson the lesson containing the updated information
	 * @param username the username of the user attempting the update
	 * @return true if the lesson was successfully updated; false otherwise
	 */
    public boolean updateLesson(LessonsLearned lesson, String username) {
        if (lesson == null || !LessonLearnedRecognizer.checkLesson(lesson.getTitle(),
                lesson.getDescription(), lesson.getCategory(), lesson.getTags()).isEmpty()) return false;
        // Locked fields retain their database values even when a caller bypasses the GUI.
        String query = "UPDATE LessonsLearned SET " +
                "title = CASE WHEN LOCATE(',title,', CONCAT(',', COALESCE(lockedFields, ''), ',')) > 0 THEN title ELSE ? END, " +
                "description = CASE WHEN LOCATE(',description,', CONCAT(',', COALESCE(lockedFields, ''), ',')) > 0 THEN description ELSE ? END, " +
                "category = CASE WHEN LOCATE(',category,', CONCAT(',', COALESCE(lockedFields, ''), ',')) > 0 THEN category ELSE ? END, " +
                "tags = CASE WHEN LOCATE(',tags,', CONCAT(',', COALESCE(lockedFields, ''), ',')) > 0 THEN tags ELSE ? END " +
                "WHERE lessonId = ? AND createdBy = ? AND locked = FALSE";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, lesson.getTitle());
            pstmt.setString(2, lesson.getDescription());
            pstmt.setString(3, lesson.getCategory());
            pstmt.setString(4, lesson.getTags());
            pstmt.setInt(5, lesson.getLessonId());
            pstmt.setString(6, username);
            return pstmt.executeUpdate() == 1;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

	/**
	 * Deletes an existing lesson.
	 *
	 * @param lessonId the ID of the lesson to delete
	 * @param username the username of the user attempting the deletion
	 * @return true if the lesson was successfully deleted; false otherwise
	 */
	public boolean deleteLesson(int lessonId, String username) {
		String query = "DELETE FROM LessonsLearned WHERE lessonId = ? AND createdBy = ? AND locked = FALSE " +
                "AND (lockedFields IS NULL OR lockedFields = '')";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, lessonId);
			pstmt.setString(2, username);
			boolean removed = pstmt.executeUpdate() == 1;
            if (removed) {
                try (PreparedStatement cleanup = connection.prepareStatement(
                        "DELETE FROM LessonExperiences WHERE lessonId = ?")) {
                    cleanup.setInt(1, lessonId);
                    cleanup.executeUpdate();
                }
            }
            return removed;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    /**
     * Changes the locked state of a lesson.
	 *
	 * @param lessonId the ID of the lesson to update
	 * @param locked true to lock the lesson; false to unlock it
	 * @return true if the locked state was successfully changed; false otherwise
	 */
	public boolean setLessonLocked(int lessonId, boolean locked) {
		String query = "UPDATE LessonsLearned SET locked = ? WHERE lessonId = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setBoolean(1, locked);
			pstmt.setInt(2, lessonId);
			return pstmt.executeUpdate() == 1;
		} catch (SQLException e) { e.printStackTrace(); }
		return false;
	}

	// Builds the LessonsLearned entity used by the database read methods.
	private LessonsLearned buildLessonFromResultSet(ResultSet rs) throws SQLException {
		LessonsLearned lesson = new LessonsLearned(rs.getInt("lessonId"), rs.getString("title"),
				rs.getString("description"), rs.getString("category"), rs.getString("tags"),
				rs.getString("createdBy"), rs.getDate("dateCreated").toLocalDate(), rs.getBoolean("locked"));
        lesson.setLockedFields(rs.getString("lockedFields"));
        return lesson;
	}


    /*******
     * <p> Method: getAllLessonsForCurator() </p>
     * <p> Description: Returns all contributor lessons for the Curator page. The query checks the current user's Curator role before returning results. </p>
     * @param username the logged-in Curator
     * @return the list of all lessons available to that Curator
     */
    public LessonsLearnedList getAllLessonsForCurator(String username) {
        LessonsLearnedList lessons = new LessonsLearnedList();
        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT * FROM LessonsLearned WHERE EXISTS (SELECT 1 FROM userDB " +
                "WHERE userName = ? AND newRole2 = TRUE) ORDER BY lessonId")) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) lessons.addLesson(buildLessonFromResultSet(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return lessons;
    }

    /*******
     * <p> Method: addLessonExperience(LessonExperience experience, String username) </p>
     * <p> Description: Records an attempt to reuse a contributor's own lesson. </p>
     * @param experience the experience information
     * @param username the contributor making the entry
     * @return true when the experience was stored
     */
    public boolean addLessonExperience(LessonExperience experience, String username) {
        if (experience == null || getLesson(experience.getLessonId(), username) == null) return false;
        if (!LessonLearnedRecognizer.checkExperience(experience.getWhatWasDone(),
                experience.getHowItWasDone(), experience.getTimeTakenMinutes(),
                experience.getEffortUsed()).isEmpty()) return false;
        String query = "INSERT INTO LessonExperiences (lessonId, whatWasDone, howItWasDone, " +
                "timeTakenMinutes, effortUsed) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, experience.getLessonId());
            pstmt.setString(2, experience.getWhatWasDone());
            pstmt.setString(3, experience.getHowItWasDone());
            pstmt.setInt(4, experience.getTimeTakenMinutes());
            pstmt.setDouble(5, experience.getEffortUsed());
            return pstmt.executeUpdate() == 1;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    /*******
     * <p> Method: getLessonExperiences(int lessonId, String username) </p>
     * <p> Description: Returns experiences for a lesson only when the requesting contributor
     * owns the lesson. </p>
     * @param lessonId the lesson to inspect
     * @param username the requesting contributor
     * @return the list of stored experiences
     */
    public List<LessonExperience> getLessonExperiences(int lessonId, String username) {
        List<LessonExperience> result = new ArrayList<LessonExperience>();
        if (getLesson(lessonId, username) == null) return result;
        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT * FROM LessonExperiences WHERE lessonId = ? ORDER BY experienceId")) {
            pstmt.setInt(1, lessonId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                LessonExperience item = new LessonExperience(lessonId, rs.getString("whatWasDone"),
                        rs.getString("howItWasDone"), rs.getInt("timeTakenMinutes"),
                        rs.getDouble("effortUsed"));
                item.setExperienceId(rs.getInt("experienceId"));
                result.add(item);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return result;
    }

    /*******
     * <p> Method: setLessonLockedByCurator(int lessonId, boolean locked, String username) </p>
     * <p> Description: Permits the Curator to lock or unlock a lesson. The user role is
     * checked again in the database rather than relying only on the GUI. </p>
     * @param lessonId the selected lesson
     * @param locked the requested lock state
     * @param username the current Curator username
     * @return true if the lesson was updated
     */
    public boolean setLessonLockedByCurator(int lessonId, boolean locked, String username) {
        String query = "UPDATE LessonsLearned SET locked = ? WHERE lessonId = ? AND " +
                "EXISTS (SELECT 1 FROM userDB WHERE userName = ? AND newRole2 = TRUE)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setBoolean(1, locked);
            pstmt.setInt(2, lessonId);
            pstmt.setString(3, username);
            return pstmt.executeUpdate() == 1;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    /**
     * Changes one field lock. Only an authenticated Curator may do this.
     * Field names are restricted to the four contributor-editable core fields.
     * @param lessonId the selected lesson
     * @param field the field to lock or unlock
     * @param locked the new state
     * @param username the Curator's username
     * @return true if the field lock was saved
     */
    public boolean setLessonFieldLockedByCurator(int lessonId, String field, boolean locked, String username) {
        if (!("title".equals(field) || "description".equals(field) ||
                "category".equals(field) || "tags".equals(field))) return false;
        String query = "SELECT lockedFields FROM LessonsLearned WHERE lessonId = ? AND " +
                "EXISTS (SELECT 1 FROM userDB WHERE userName = ? AND newRole2 = TRUE)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, lessonId);
            pstmt.setString(2, username);
            ResultSet rs = pstmt.executeQuery();
            if (!rs.next()) return false;
            java.util.Set<String> fields = new java.util.LinkedHashSet<String>();
            String existing = rs.getString(1);
            if (existing != null && !existing.isEmpty())
                fields.addAll(java.util.Arrays.asList(existing.split(",")));
            if (locked) fields.add(field); else fields.remove(field);
            String update = "UPDATE LessonsLearned SET lockedFields = ? WHERE lessonId = ? AND " +
                    "EXISTS (SELECT 1 FROM userDB WHERE userName = ? AND newRole2 = TRUE)";
            try (PreparedStatement stmt = connection.prepareStatement(update)) {
                stmt.setString(1, String.join(",", fields));
                stmt.setInt(2, lessonId);
                stmt.setString(3, username);
                return stmt.executeUpdate() == 1;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

}




