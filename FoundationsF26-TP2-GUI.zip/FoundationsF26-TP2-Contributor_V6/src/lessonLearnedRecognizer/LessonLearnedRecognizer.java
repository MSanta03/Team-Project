package lessonLearnedRecognizer;

/*******
 * <p> Title: LessonLearnedRecognizer Class </p>
 * 
 * <p> Description: This class validates the user supplied core information for a Lesson Learned.
 * An empty String is returned when the input is valid.  A descriptive error message is returned
 * when the input is invalid so the same validation can be used by the GUI and automated tests. </p>
 * 
 * <p> Copyright: Jacob Yates © 2026 </p>
 * 
 * @author Jacob Yates
 * 
 * @version 1.00		2026-10-05 Initial implementation for HW2
 */
public class LessonLearnedRecognizer {
	private static final int TITLE_LIMIT = 100;
	private static final int DESCRIPTION_LIMIT = 2000;
	private static final int TAGS_LIMIT = 255;
	private static final String[] CATEGORIES = {
			"General", "Technical", "Teamwork", "Project Management",
			"Communication", "Research", "Career"
	};

/*****
	 * <p> Method: LessonLearnedRecognizer() </p>
	 * <p> Description: Default constructor for the Lesson Learned recognizer. </p>
	 */
	public LessonLearnedRecognizer() {
	}

/*****
	 * <p> Method: checkTitle(String input) </p>
	 * <p> Description: Validates that a lesson title is present and does not exceed the allowed length. </p>
	 * @param input specifies the title to validate
	 * @return an empty String when valid or a descriptive error message when invalid
	 */
	public static String checkTitle(String input) {
		if (input == null || input.trim().isEmpty()) return "The lesson title cannot be empty.";
		if (input.length() > TITLE_LIMIT) return "The lesson title cannot exceed 100 characters.";
		return "";
	}

/*****
	 * <p> Method: checkDescription(String input) </p>
	 * <p> Description: Validates that a lesson description is present and does not exceed the allowed length. </p>
	 * @param input specifies the description to validate
	 * @return an empty String when valid or a descriptive error message when invalid
	 */
	public static String checkDescription(String input) {
		if (input == null || input.trim().isEmpty()) return "The lesson description cannot be empty.";
		if (input.length() > DESCRIPTION_LIMIT) return "The lesson description cannot exceed 2000 characters.";
		return "";
	}

/*****
	 * <p> Method: checkCategory(String input) </p>
	 * <p> Description: Validates that a category was supplied and is one of the supported lesson categories. </p>
	 * @param input specifies the category to validate
	 * @return an empty String when valid or a descriptive error message when invalid
	 */
	public static String checkCategory(String input) {
		if (input == null || input.trim().isEmpty()) return "A lesson category must be selected.";
		for (String category : CATEGORIES)
			if (category.equals(input)) return "";
		return "The selected lesson category is not valid.";
	}

/*****
	 * <p> Method: checkTags(String input) </p>
	 * <p> Description: Validates the optional lesson tags, including the total length and empty-tag rule. </p>
	 * @param input specifies the comma-separated tags to validate
	 * @return an empty String when valid or a descriptive error message when invalid
	 */
	public static String checkTags(String input) {
		if (input == null || input.isEmpty()) return "";
		if (input.length() > TAGS_LIMIT) return "The lesson tags cannot exceed 255 characters.";
		String[] tags = input.split(",", -1);
		for (String tag : tags)
			if (tag.trim().isEmpty()) return "Lesson tags cannot contain an empty tag.";
		return "";
	}

/*****
	 * <p> Method: checkLesson(String title, String description, String category, String tags) </p>
	 * <p> Description: Validates all core information for a lesson and returns the first validation error found. </p>
	 * @param title specifies the lesson title
	 * @param description specifies the lesson description
	 * @param category specifies the lesson category
	 * @param tags specifies the lesson tags
	 * @return an empty String when all information is valid or a descriptive error message when invalid
	 */
	public static String checkLesson(String title, String description, String category, String tags) {
		String result = checkTitle(title);
		if (!result.equals("")) return result;
		result = checkDescription(description);
		if (!result.equals("")) return result;
		result = checkCategory(category);
		if (!result.equals("")) return result;
		return checkTags(tags);
	}

/*****
	 * <p> Method: checkExperience(String whatWasDone, String howItWasDone, int timeTakenMinutes, double effortUsed) </p>
	 * <p> Description: Validates the information supplied when a Contributor records experience using a lesson. </p>
	 * @param whatWasDone specifies what the Contributor did
	 * @param howItWasDone specifies how the Contributor performed the work
	 * @param timeTakenMinutes specifies the time taken in minutes
	 * @param effortUsed specifies the amount of effort used
	 * @return an empty String when all information is valid or a descriptive error message when invalid
	 */
	public static String checkExperience(String whatWasDone, String howItWasDone, int timeTakenMinutes, double effortUsed) {
		if (whatWasDone == null || whatWasDone.trim().isEmpty()) return "What was done cannot be empty.";
		if (whatWasDone.length() > DESCRIPTION_LIMIT) return "What was done cannot exceed 2000 characters.";
		if (howItWasDone == null || howItWasDone.trim().isEmpty()) return "How it was done cannot be empty.";
		if (howItWasDone.length() > DESCRIPTION_LIMIT) return "How it was done cannot exceed 2000 characters.";
		if (timeTakenMinutes < 0) return "Time taken cannot be negative.";
		if (!Double.isFinite(effortUsed) || effortUsed < 0) return "Effort used must be a finite, nonnegative number.";
		return "";
	}
}
