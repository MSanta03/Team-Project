package entityClasses;

/*******
 * <p> Title: LessonExperience Class </p>
 * 
 * <p> Description: This class represents experience information added after a Contributor
 * attempts to leverage an existing lesson learned. </p>
 * 
 * <p> Copyright: Jacob Yates © 2026 </p>
 * 
 * @author Jacob Yates
 * 
 * @version 1.00		2026-10-05 Initial implementation for HW2
 */
public class LessonExperience {
	private int experienceId;
	private int lessonId;
	private String whatWasDone;
	private String howItWasDone;
	private int timeTakenMinutes;
	private double effortUsed;

/*****
	 * <p> Method: LessonExperience() </p>
	 * <p> Description: Default constructor used before all experience information has been supplied. </p>
	 */
	public LessonExperience() {
	}

/*****
	 * <p> Method: LessonExperience(int lessonId, String whatWasDone, String howItWasDone, int timeTakenMinutes, double effortUsed) </p>
	 * <p> Description: Constructor used to establish experience information for an existing lesson. </p>
	 * @param lessonId specifies the lesson associated with the experience
	 * @param whatWasDone specifies what the Contributor did
	 * @param howItWasDone specifies how the Contributor performed the work
	 * @param timeTakenMinutes specifies the time taken in minutes
	 * @param effortUsed specifies the amount of effort used
	 */
	public LessonExperience(int lessonId, String whatWasDone, String howItWasDone,
			int timeTakenMinutes, double effortUsed) {
		this.lessonId = lessonId;
		this.whatWasDone = whatWasDone;
		this.howItWasDone = howItWasDone;
		this.timeTakenMinutes = timeTakenMinutes;
		this.effortUsed = effortUsed;
	}

/*****
	 * <p> Method: getExperienceId() </p>
	 * <p> Description: Returns the unique identifier for this experience. </p>
	 * @return the experience identifier
	 */
	public int getExperienceId() { return experienceId; }
/*****
	 * <p> Method: getLessonId() </p>
	 * <p> Description: Returns the identifier of the lesson associated with this experience. </p>
	 * @return the lesson identifier
	 */
	public int getLessonId() { return lessonId; }
/*****
	 * <p> Method: getWhatWasDone() </p>
	 * <p> Description: Returns what the Contributor did while using the lesson. </p>
	 * @return the description of what was done
	 */
	public String getWhatWasDone() { return whatWasDone; }
/*****
	 * <p> Method: getHowItWasDone() </p>
	 * <p> Description: Returns how the Contributor performed the work. </p>
	 * @return the description of how it was done
	 */
	public String getHowItWasDone() { return howItWasDone; }
/*****
	 * <p> Method: getTimeTakenMinutes() </p>
	 * <p> Description: Returns the amount of time taken in minutes. </p>
	 * @return the time taken in minutes
	 */
	public int getTimeTakenMinutes() { return timeTakenMinutes; }
/*****
	 * <p> Method: getEffortUsed() </p>
	 * <p> Description: Returns the amount of effort used. </p>
	 * @return the effort used
	 */
	public double getEffortUsed() { return effortUsed; }

/*****
	 * <p> Method: setExperienceId(int value) </p>
	 * <p> Description: Sets the unique identifier for this experience. </p>
	 * @param value specifies the experience identifier
	 */
	public void setExperienceId(int value) { experienceId = value; }
/*****
	 * <p> Method: setLessonId(int value) </p>
	 * <p> Description: Sets the identifier of the associated lesson. </p>
	 * @param value specifies the lesson identifier
	 */
	public void setLessonId(int value) { lessonId = value; }
/*****
	 * <p> Method: setWhatWasDone(String value) </p>
	 * <p> Description: Sets the description of what the Contributor did. </p>
	 * @param value specifies what was done
	 */
	public void setWhatWasDone(String value) { whatWasDone = value; }
/*****
	 * <p> Method: setHowItWasDone(String value) </p>
	 * <p> Description: Sets the description of how the work was performed. </p>
	 * @param value specifies how the work was done
	 */
	public void setHowItWasDone(String value) { howItWasDone = value; }
/*****
	 * <p> Method: setTimeTakenMinutes(int value) </p>
	 * <p> Description: Sets the amount of time taken in minutes. </p>
	 * @param value specifies the time taken in minutes
	 */
	public void setTimeTakenMinutes(int value) { timeTakenMinutes = value; }
/*****
	 * <p> Method: setEffortUsed(double value) </p>
	 * <p> Description: Sets the amount of effort used. </p>
	 * @param value specifies the effort used
	 */
	public void setEffortUsed(double value) { effortUsed = value; }
}
