package entityClasses;

import java.time.LocalDate;

/*******
 * <p> Title: LessonsLearned Class </p>
 * 
 * <p> Description: This LessonsLearned class represents a lesson learned entity in the system.
 * It contains the core information needed to describe a lesson and identify the Contributor who
 * created it. </p>
 * 
 * <p> Copyright: Jacob Yates © 2026 </p>
 * 
 * @author Jacob Yates
 * 
 * @version 1.00		2026-10-05 Initial implementation for HW2
 */
public class LessonsLearned {
	
	/*
	 * These are the private attributes for this entity object
	 */
	private int lessonId;
	private String title;
	private String description;
	private String category;
	private String tags;
	private String createdBy;
	private LocalDate dateCreated;
	private boolean locked;

	/*****
	 * <p> Method: LessonsLearned() </p>
	 * 
	 * <p> Description: Default constructor used when establishing a lesson object before all
	 * attributes have been supplied. </p>
	 */
	public LessonsLearned() {
	}

	/*****
	 * <p> Method: LessonsLearned(String title, String description, String category, String tags,
	 * String createdBy) </p>
	 * 
	 * <p> Description: Constructor used to establish a new lesson learned entity object. </p>
	 * 
	 * @param title specifies the title of the lesson
	 * @param description specifies what was learned
	 * @param category specifies the category used to organize the lesson
	 * @param tags specifies keywords associated with the lesson
	 * @param createdBy specifies the Contributor who created the lesson
	 */
	public LessonsLearned(String title, String description, String category, String tags, String createdBy) {
		this(0, title, description, category, tags, createdBy, LocalDate.now(), false);
	}

	/**
	 * Constructs a LessonsLearned object.
	 *
	 * @param lessonId the unique ID of the lesson
	 * @param title the title of the lesson
	 * @param description the description of the lesson
	 * @param category the category assigned to the lesson
	 * @param tags the tags associated with the lesson
	 * @param createdBy the username of the lesson's creator
	 * @param dateCreated the date the lesson was created
	 * @param locked whether the lesson is currently locked
	 */
	public LessonsLearned(int lessonId, String title, String description, String category, String tags,
			String createdBy, LocalDate dateCreated, boolean locked) {
		this.lessonId = lessonId;
		this.title = title;
		this.description = description;
		this.category = category;
		this.tags = tags;
		this.createdBy = createdBy;
		this.dateCreated = dateCreated;
		this.locked = locked;
	}

/*****
	 * <p> Method: getLessonId() </p>
	 * <p> Description: Returns the unique identifier for this lesson. </p>
	 * @return the lesson identifier
	 */
	public int getLessonId() { return lessonId; }
/*****
	 * <p> Method: getTitle() </p>
	 * <p> Description: Returns the title of this lesson. </p>
	 * @return the lesson title
	 */
	public String getTitle() { return title; }
/*****
	 * <p> Method: getDescription() </p>
	 * <p> Description: Returns the description of what was learned. </p>
	 * @return the lesson description
	 */
	public String getDescription() { return description; }
/*****
	 * <p> Method: getCategory() </p>
	 * <p> Description: Returns the category used to organize this lesson. </p>
	 * @return the lesson category
	 */
	public String getCategory() { return category; }
/*****
	 * <p> Method: getTags() </p>
	 * <p> Description: Returns the tags associated with this lesson. </p>
	 * @return the lesson tags
	 */
	public String getTags() { return tags; }
/*****
	 * <p> Method: getCreatedBy() </p>
	 * <p> Description: Returns the Contributor who created this lesson. </p>
	 * @return the Contributor username
	 */
	public String getCreatedBy() { return createdBy; }
/*****
	 * <p> Method: getDateCreated() </p>
	 * <p> Description: Returns the date on which this lesson was created. </p>
	 * @return the creation date
	 */
	public LocalDate getDateCreated() { return dateCreated; }
/*****
	 * <p> Method: getLocked() </p>
	 * <p> Description: Returns whether this lesson is currently locked from modification. </p>
	 * @return true when the lesson is locked; otherwise false
	 */
	public boolean getLocked() { return locked; }

/*****
	 * <p> Method: setLessonId(int value) </p>
	 * <p> Description: Sets the unique identifier for this lesson. </p>
	 * @param value specifies the lesson identifier
	 */
	public void setLessonId(int value) { lessonId = value; }
/*****
	 * <p> Method: setTitle(String value) </p>
	 * <p> Description: Sets the title of this lesson. </p>
	 * @param value specifies the lesson title
	 */
	public void setTitle(String value) { title = value; }
/*****
	 * <p> Method: setDescription(String value) </p>
	 * <p> Description: Sets the description of what was learned. </p>
	 * @param value specifies the lesson description
	 */
	public void setDescription(String value) { description = value; }
/*****
	 * <p> Method: setCategory(String value) </p>
	 * <p> Description: Sets the category used to organize this lesson. </p>
	 * @param value specifies the lesson category
	 */
	public void setCategory(String value) { category = value; }
/*****
	 * <p> Method: setTags(String value) </p>
	 * <p> Description: Sets the tags associated with this lesson. </p>
	 * @param value specifies the lesson tags
	 */
	public void setTags(String value) { tags = value; }
/*****
	 * <p> Method: setCreatedBy(String value) </p>
	 * <p> Description: Sets the Contributor who created this lesson. </p>
	 * @param value specifies the Contributor username
	 */
	public void setCreatedBy(String value) { createdBy = value; }
/*****
	 * <p> Method: setDateCreated(LocalDate value) </p>
	 * <p> Description: Sets the date on which this lesson was created. </p>
	 * @param value specifies the creation date
	 */
	public void setDateCreated(LocalDate value) { dateCreated = value; }
/*****
	 * <p> Method: setLocked(boolean value) </p>
	 * <p> Description: Sets whether this lesson is locked from modification. </p>
	 * @param value specifies the locked state
	 */
	public void setLocked(boolean value) { locked = value; }
}
