package guiUserUpdate;
/**
 * Model used by the user update interface.
 */
public class Model {
	  /**
     * Constructs a user update Model object.
     */
    public Model() {
    }
}
