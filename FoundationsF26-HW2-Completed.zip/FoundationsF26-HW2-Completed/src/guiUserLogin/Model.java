package guiUserLogin;
/**
 * Model used by the user login interface.
 */
public class Model {
    /**
     * Constructs a user login Model object.
     */
    public Model() {
    }
}
