/**
 * Defines the Combined application module and its required packages.
 */
module Combined {
	requires javafx.controls;
	requires java.sql;
	
	opens applicationMain to javafx.graphics, javafx.fxml;
}
