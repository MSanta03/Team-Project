package lessonLearnedTests;

import java.sql.SQLException;

import database.Database;
import entityClasses.LessonsLearned;
import entityClasses.LessonsLearnedList;

/*******
 * <p> Title: LessonLearnedCRUDTestAutomation Class. </p>
 * 
 * <p> Description: A Java demonstration of automated tests for the Lessons Learned database
 * Create, Read, Update, and Delete methods required for HW2. </p>
 * 
 * <p> Copyright: Jacob Yates © 2026 </p>
 * 
 * @author Jacob Yates
 * 
 * @version 1.00	2026-10-05 Initial automated CRUD tests for HW2
 */
public class LessonLearnedCRUDTestAutomation {
	
	/**
	 * Constructs a LessonLearnedCRUDTestAutomation object.
	 */
	public LessonLearnedCRUDTestAutomation() {
	}
	
	static int numPassed = 0;	// Counter of the number of passed tests
	static int numFailed = 0;	// Counter of the number of failed tests
	static Database database = new Database();
	static String testUser = "HW2TestContributor";
	static int lessonId = 0;

	/**
	 * Runs the Lessons Learned CRUD test cases.
	 *
	 * @param args command-line arguments; not used
	 */
	public static void main(String[] args) {
		System.out.println("______________________________________");
		System.out.println("\nLessons Learned CRUD Test Automation");
		
		try {
			database.connectToDatabase();
			
			performCreateTest(1);
			performReadTest(2);
			performListTest(3);
			performOwnershipReadTest(4);
			performUpdateTest(5);
			performOwnershipUpdateTest(6);
			performLockTest(7);
			performLockedUpdateTest(8);
			performLockedDeleteTest(9);
			performUnlockTest(10);
			performDeleteTest(11);
			performDeletedReadTest(12);
		}
		catch (SQLException e) {
			System.out.println("***Failure*** The database could not be opened for testing.");
			e.printStackTrace();
			numFailed++;
		}
		finally {
			database.closeConnection();
		}
		
		System.out.println("______________________________________");
		System.out.println();
		System.out.println("Number of tests passed: " + numPassed);
		System.out.println("Number of tests failed: " + numFailed);
	}

	private static void performCreateTest(int testCase) {
		LessonsLearned lesson = new LessonsLearned("HW2 CRUD Test Lesson",
				"This lesson is created by the automated CRUD test.", "Technical",
				"hw2, testing", testUser);
		boolean result = database.createLesson(lesson);
		lessonId = lesson.getLessonId();
		reportResult(testCase, "Create a new lesson", result && lessonId > 0);
	}

	private static void performReadTest(int testCase) {
		LessonsLearned lesson = database.getLesson(lessonId, testUser);
		boolean result = lesson != null && lesson.getTitle().equals("HW2 CRUD Test Lesson")
				&& lesson.getCreatedBy().equals(testUser);
		reportResult(testCase, "Read the lesson that was created", result);
	}

	private static void performListTest(int testCase) {
		LessonsLearnedList lessons = database.getLessonsForContributor(testUser);
		boolean found = false;
		for (LessonsLearned lesson : lessons.getLessons())
			if (lesson.getLessonId() == lessonId) found = true;
		reportResult(testCase, "Read the Contributor's lesson list", found);
	}

	private static void performOwnershipReadTest(int testCase) {
		LessonsLearned lesson = database.getLesson(lessonId, "DifferentContributor");
		reportResult(testCase, "Prevent another Contributor from reading through the owner method", lesson == null);
	}

	private static void performUpdateTest(int testCase) {
		LessonsLearned lesson = database.getLesson(lessonId, testUser);
		lesson.setTitle("HW2 CRUD Test Lesson Updated");
		boolean updated = database.updateLesson(lesson, testUser);
		LessonsLearned result = database.getLesson(lessonId, testUser);
		reportResult(testCase, "Update an unlocked lesson", updated && result != null
				&& result.getTitle().equals("HW2 CRUD Test Lesson Updated"));
	}

	private static void performOwnershipUpdateTest(int testCase) {
		LessonsLearned lesson = database.getLesson(lessonId, testUser);
		lesson.setTitle("This update should not be saved");
		boolean result = database.updateLesson(lesson, "DifferentContributor");
		reportResult(testCase, "Prevent another Contributor from updating the lesson", !result);
	}

	private static void performLockTest(int testCase) {
		boolean result = database.setLessonLocked(lessonId, true);
		LessonsLearned lesson = database.getLesson(lessonId, testUser);
		reportResult(testCase, "Lock the lesson", result && lesson != null && lesson.getLocked());
	}

	private static void performLockedUpdateTest(int testCase) {
		LessonsLearned lesson = database.getLesson(lessonId, testUser);
		lesson.setTitle("Locked lesson update");
		boolean result = database.updateLesson(lesson, testUser);
		reportResult(testCase, "Prevent an update while the lesson is locked", !result);
	}

	private static void performLockedDeleteTest(int testCase) {
		boolean result = database.deleteLesson(lessonId, testUser);
		reportResult(testCase, "Prevent deletion while the lesson is locked", !result);
	}

	private static void performUnlockTest(int testCase) {
		boolean result = database.setLessonLocked(lessonId, false);
		LessonsLearned lesson = database.getLesson(lessonId, testUser);
		reportResult(testCase, "Unlock the lesson", result && lesson != null && !lesson.getLocked());
	}

	private static void performDeleteTest(int testCase) {
		boolean result = database.deleteLesson(lessonId, testUser);
		reportResult(testCase, "Delete the unlocked lesson", result);
	}

	private static void performDeletedReadTest(int testCase) {
		LessonsLearned lesson = database.getLesson(lessonId, testUser);
		reportResult(testCase, "Verify the deleted lesson no longer exists", lesson == null);
	}

	private static void reportResult(int testCase, String description, boolean passed) {
		System.out.println("______________________________________\n\nTest case: " + testCase);
		System.out.println(description);
		if (passed) {
			System.out.println("***Success*** The test passed.");
			numPassed++;
		}
		else {
			System.out.println("***Failure*** The test failed.");
			numFailed++;
		}
	}
}
