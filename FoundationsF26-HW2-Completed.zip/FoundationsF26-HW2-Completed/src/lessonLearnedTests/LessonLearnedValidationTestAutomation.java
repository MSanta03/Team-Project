package lessonLearnedTests;

import lessonLearnedRecognizer.LessonLearnedRecognizer;

/*******
 * <p> Title: LessonLearnedValidationTestAutomation Class. </p>
 * 
 * <p> Description: A Java demonstration of automated tests for the Lessons Learned input
 * validation rules.  These tests use the same recognizer methods that the application uses. </p>
 * 
 * <p> Copyright: Jacob Yates © 2026 </p>
 * 
 * @author Jacob Yates
 * 
 * @version 1.00	2026-10-05 Initial automated validation tests for HW2
 */
public class LessonLearnedValidationTestAutomation {
	
	/**
	 * Constructs a LessonLearnedValidationTestAutomation object.
	 */
	public LessonLearnedValidationTestAutomation() {
	}
	
	static int numPassed = 0;	// Counter of the number of passed tests
	static int numFailed = 0;	// Counter of the number of failed tests

	/**
	 * Runs the Lessons Learned validation test cases.
	 *
	 * @param args command-line arguments; not used
	 */
	public static void main(String[] args) {
		/************** Test cases automation report header **************/
		System.out.println("______________________________________");
		System.out.println("\nLessons Learned Validation Test Automation");

		/************** Start of the test cases **************/
		performTestCase(1, "Valid lesson", "A useful lesson learned during the project.",
				"Technical", "java, database", true);
		performTestCase(2, "", "A useful lesson learned during the project.",
				"Technical", "java, database", false);
		performTestCase(3, "Valid lesson", "", "Technical", "java, database", false);
		performTestCase(4, "Valid lesson", "A useful lesson learned during the project.",
				"Not a Category", "java, database", false);
		performTestCase(5, "Valid lesson", "A useful lesson learned during the project.",
				"Teamwork", "", true);
		performTestCase(6, "Valid lesson", "A useful lesson learned during the project.",
				"Teamwork", "git,,teamwork", false);
		performTestCase(7, repeatCharacter('A', 100), "Valid description",
				"General", "testing", true);
		performTestCase(8, repeatCharacter('A', 101), "Valid description",
				"General", "testing", false);
		performTestCase(9, "Valid lesson", repeatCharacter('B', 2000),
				"Research", "testing", true);
		performTestCase(10, "Valid lesson", repeatCharacter('B', 2001),
				"Research", "testing", false);
		performExperienceTestCase(11, "Added lesson support", "Used the database methods", 60, 3.0, true);
		performExperienceTestCase(12, "", "Used the database methods", 60, 3.0, false);
		performExperienceTestCase(13, "Added lesson support", "", 60, 3.0, false);
		performExperienceTestCase(14, "Added lesson support", "Used the database methods", -1, 3.0, false);
		performExperienceTestCase(15, "Added lesson support", "Used the database methods", 60, -1.0, false);
		/************** End of the test cases **************/

		/************** Test cases automation report footer **************/
		System.out.println("______________________________________");
		System.out.println();
		System.out.println("Number of tests passed: " + numPassed);
		System.out.println("Number of tests failed: " + numFailed);
	}

	/**
	 * Performs one test of the complete core Lesson Learned input.
	 */
	private static void performTestCase(int testCase, String title, String description,
			String category, String tags, boolean expectedPass) {
		System.out.println("______________________________________\n\nTest case: " + testCase);
		System.out.println("Title: \"" + title + "\"");
		System.out.println("Category: \"" + category + "\"");
		
		String resultText = LessonLearnedRecognizer.checkLesson(title, description, category, tags);
		interpretResult(resultText, expectedPass);
	}

	/**
	 * Performs one test of the experience information validation.
	 */
	private static void performExperienceTestCase(int testCase, String whatWasDone, String howItWasDone,
			int timeTakenMinutes, double effortUsed, boolean expectedPass) {
		System.out.println("______________________________________\n\nTest case: " + testCase);
		System.out.println("Experience validation test");
		
		String resultText = LessonLearnedRecognizer.checkExperience(whatWasDone, howItWasDone,
				timeTakenMinutes, effortUsed);
		interpretResult(resultText, expectedPass);
	}

	/**
	 * Compares the recognizer result with the expected result and updates the test counters.
	 */
	private static void interpretResult(String resultText, boolean expectedPass) {
		boolean actualPass = resultText.equals("");
		if (actualPass == expectedPass) {
			System.out.println("***Success*** The result matched the expected result.");
			if (!actualPass) System.out.println("Error message: " + resultText);
			numPassed++;
		}
		else {
			System.out.println("***Failure*** The result did not match the expected result.");
			if (!actualPass) System.out.println("Error message: " + resultText);
			numFailed++;
		}
	}

	/**
	 * Creates a String of the requested length for boundary value tests.
	 */
	private static String repeatCharacter(char character, int length) {
		StringBuilder result = new StringBuilder();
		for (int ndx = 0; ndx < length; ndx++) result.append(character);
		return result.toString();
	}
}
